package com.test.test;

import org.springframework.data.jpa.repository.JpaRepository;

public interface KriptoParaRepository extends JpaRepository<KriptoPara, Long> {
}
